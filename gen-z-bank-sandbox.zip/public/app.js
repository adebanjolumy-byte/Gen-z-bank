const $ = id => document.getElementById(id);

async function api(url, options={}) {
  const r = await fetch(url,{
    headers:{"Content-Type":"application/json"},
    ...options
  });
  const data = await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error || "Request failed");
  return data;
}

function showSignup(){$("login").classList.add("hide");$("signup").classList.remove("hide")}
function showLogin(){$("signup").classList.add("hide");$("login").classList.remove("hide")}

async function signup(){
  try{
    await api("/api/signup",{method:"POST",body:JSON.stringify({
      fullName:$("suName").value,
      phone:$("suPhone").value,
      email:$("suEmail").value,
      loginPin:$("suLoginPin").value,
      transferPin:$("suTransferPin").value
    })});
    alert("Account created successfully. Please log in.");
    showLogin();
  }catch(e){alert(e.message)}
}

async function login(){
  try{
    const d=await api("/api/login",{method:"POST",body:JSON.stringify({
      identity:$("liIdentity").value,
      loginPin:$("liPin").value
    })});
    openApp(d.user);
  }catch(e){alert(e.message)}
}

function openApp(user){
  $("auth").classList.add("hide");
  $("app").classList.remove("hide");
  renderUser(user);
  loadTransactions();
  if(!user.welcomeClaimed) showWelcome();
}

function renderUser(u){
  $("hello").textContent=`Hello, ${u.fullName}`;
  $("accountHolder").textContent=u.fullName;
  $("balance").textContent=Number(u.balance).toLocaleString();
}

async function refresh(){
  const d=await api("/api/me");
  renderUser(d.user);
  loadTransactions();
}

async function logout(){
  await api("/api/logout",{method:"POST"});
  location.reload();
}

function showWelcome(){
  modal(`
    <h2>Welcome to Gen Z Bank</h2>
    <p>You have been credited with a free <b>₦75,000 demo welcome credit</b>.</p>
    <button class="primary" onclick="claimWelcome()">CLICK HERE TO ACCEPT</button>
  `);
}

async function claimWelcome(){
  try{
    await api("/api/claim-welcome",{method:"POST"});
    closeModal();
    await refresh();
  }catch(e){alert(e.message)}
}

async function loadTransactions(){
  try{
    const d=await api("/api/transactions");
    $("transactions").innerHTML=d.transactions.length
      ? d.transactions.map(t=>`
        <div class="tx">
          <div><b>${escapeHtml(t.description)}</b><br><small>${escapeHtml(t.createdAt)} · ${escapeHtml(t.reference)}</small></div>
          <span class="${t.amount>=0?"credit":"debit"}">${t.amount>=0?"+":"-"}₦${Math.abs(t.amount).toLocaleString()}</span>
        </div>`).join("")
      : "No transactions yet.";
  }catch(e){}
}

function openTransfer(){
  modal(`
    <h2>Transfer Money</h2>
    <input id="accountNumber" maxlength="10" inputmode="numeric" placeholder="ACCOUNT NUMBER">
    <select id="bank"></select>
    <div id="lookup" style="background:#f5f5f5;padding:12px;border-radius:10px;margin:8px 0">Enter account number and select a bank.</div>
    <button class="primary" onclick="lookup()">PROCEED</button>
    <button class="secondary" onclick="closeModal()">CANCEL</button>
  `);
  loadBanks();
}

async function loadBanks(){
  const d=await api("/api/banks");
  $("bank").innerHTML='<option value="">SELECT BANK</option>'+d.banks.map(b=>`<option>${escapeHtml(b)}</option>`).join("");
}

async function lookup(){
  const account=$("accountNumber").value;
  const bank=$("bank").value;
  try{
    const d=await api("/api/account-lookup",{method:"POST",body:JSON.stringify({accountNumber:account,bank})});
    modal(`
      <h2>Transfer Details</h2>
      <div style="background:#f5f5f5;padding:14px;border-radius:10px;margin-bottom:12px">
        <b>Account Name:</b> ${escapeHtml(d.accountName)}<br>
        <b>Account Number:</b> ${escapeHtml(d.accountNumber)}<br>
        <b>Bank:</b> ${escapeHtml(d.bank)}
      </div>
      <input id="amount" type="number" min="1" placeholder="AMOUNT">
      <input id="narration" placeholder="NARRATION">
      <button class="primary" onclick='requestPin(${JSON.stringify(d)})'>SEND</button>
      <button class="secondary" onclick="closeModal()">CANCEL</button>
    `);
  }catch(e){alert(e.message)}
}

function requestPin(recipient){
  const amount=Number($("amount").value);
  const narration=$("narration").value || "Transfer";
  if(!amount || amount<=0)return alert("Enter a valid amount.");
  modal(`
    <h2>Confirm Transfer</h2>
    <p>Please confirm the account details before entering your 4-digit transfer PIN.</p>
    <div style="background:#f5f5f5;padding:14px;border-radius:10px;margin-bottom:12px">
      <b>${escapeHtml(recipient.accountName)}</b><br>
      ${escapeHtml(recipient.accountNumber)}<br>
      ${escapeHtml(recipient.bank)}<br><br>
      Amount: <b>₦${amount.toLocaleString()}</b>
    </div>
    <input id="transferPin" type="password" maxlength="4" inputmode="numeric" placeholder="4 DIGIT TRANSFER PIN">
    <button class="primary" onclick='sendTransfer(${JSON.stringify(recipient)},${amount},${JSON.stringify(narration)})'>CONFIRM & SEND</button>
    <button class="secondary" onclick="closeModal()">CANCEL</button>
  `);
}

async function sendTransfer(recipient,amount,narration){
  try{
    const d=await api("/api/transfer",{method:"POST",body:JSON.stringify({
      accountNumber:recipient.accountNumber,
      bank:recipient.bank,
      amount,
      narration,
      transferPin:$("transferPin").value
    })});
    showReceipt(d);
    await refresh();
  }catch(e){alert(e.message)}
}

function showReceipt(d){
  modal(`
    <h2 style="color:#15803d">✓ Money Sent Successfully</h2>
    <div class="receipt">
      <div><b>Status</b><span>Successful</span></div>
      <div><b>Recipient</b><span>${escapeHtml(d.recipient.name)}</span></div>
      <div><b>Account</b><span>${escapeHtml(d.recipient.account)}</span></div>
      <div><b>Bank</b><span>${escapeHtml(d.recipient.bank)}</span></div>
      <div><b>Amount</b><span>₦${d.amount.toLocaleString()}</span></div>
      <div><b>Narration</b><span>${escapeHtml(d.narration)}</span></div>
      <div><b>Reference</b><span>${escapeHtml(d.reference)}</span></div>
    </div>
    <p><small>DEMO ONLY — no real bank transfer was made.</small></p>
    <button class="primary" onclick="window.print()">PRINT RECEIPT</button>
    <button class="secondary" onclick="closeModal()">CLOSE</button>
  `);
}

function openDeposit(){
  modal(`
    <h2>Account Upgrade Required</h2>
    <p>KINDLY UPGRADE YOUR ACCOUNT TO BE ABLE TO DEPOSIT MONEY.</p>
    <p>MESSAGE <b>08036233499</b> TO UPGRADE YOUR ACCOUNT.</p>
    <a class="primary" style="display:block;text-align:center;text-decoration:none" href="https://wa.me/2348036233499" target="_blank">CHAT ON WHATSAPP</a>
    <button class="secondary" onclick="closeModal()">CLOSE</button>
  `);
}

function whatsapp(){window.open("https://wa.me/2348036233499","_blank")}
function scrollHistory(){$("history").scrollIntoView({behavior:"smooth"})}

function modal(html){
  $("modal").innerHTML=`<div class="modal-box">${html}</div>`;
  $("modal").classList.remove("hide");
}
function closeModal(){$("modal").classList.add("hide");$("modal").innerHTML=""}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}

(async function(){
  try{
    const d=await api("/api/me");
    openApp(d.user);
  }catch(e){}
})();
