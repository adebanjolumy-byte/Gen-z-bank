# Gen Z Bank — Sandbox Prototype

This is a full-stack demonstration app.

## Included

- Sign up with full name, phone, email
- 6-digit login PIN
- 4-digit transfer PIN
- Login
- Dashboard
- Simulated ₦75,000 welcome credit
- Simulated ₦1,000 daily reward
- Transaction history
- Nigerian bank list
- Simulated account lookup
- Transfer flow and transfer PIN
- Demo transaction receipt
- Deposit upgrade message
- WhatsApp customer care: 08036233499
- SQLite database
- PIN hashing with bcrypt

## Important

This application does NOT connect to Nigerian banks and does NOT transfer real money.

The account lookup is simulated and always returns "Demo Recipient".
The ₦75,000 and ₦1,000 amounts are sandbox credits.

For real-money functionality, use an authorised payment/banking provider and implement the provider's current API, webhook verification, KYC/AML requirements, security controls, and applicable regulatory requirements.

## Run locally

Install Node.js 18+.

Then:

```bash
npm install
npm start
```

Open:

http://localhost:3000

Set a strong SESSION_SECRET environment variable before deployment.

## Production hardening

Before any real-money deployment:

- Use HTTPS.
- Store secrets in environment variables.
- Use a production session store.
- Add CSRF protection where applicable.
- Add rate limiting and account lockout.
- Add email/phone verification.
- Use server-side authorization for every financial operation.
- Never store raw PINs.
- Add audit logs.
- Do not trust client-side balances.
- Replace the sandbox lookup and transfer endpoints with an authorised provider.
- Add idempotency keys and webhook signature verification.
- Complete applicable KYC/AML and licensing/compliance work.
