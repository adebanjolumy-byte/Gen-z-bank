const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database("genz-bank.sqlite");

db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  login_pin_hash TEXT NOT NULL,
  transfer_pin_hash TEXT NOT NULL,
  balance INTEGER NOT NULL DEFAULT 0,
  welcome_claimed INTEGER NOT NULL DEFAULT 0,
  last_daily_reward TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  amount INTEGER NOT NULL,
  description TEXT NOT NULL,
  narration TEXT,
  recipient_name TEXT,
  recipient_account TEXT,
  recipient_bank TEXT,
  reference TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE_THIS_SESSION_SECRET",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

app.use(express.static(path.join(__dirname, "public")));

const banks = [
  "Access Bank","Citibank Nigeria","Ecobank Nigeria","Fidelity Bank",
  "First Bank of Nigeria","First City Monument Bank (FCMB)","Globus Bank",
  "Guaranty Trust Bank (GTBank)","Jaiz Bank","Keystone Bank","LOTUS Bank",
  "Moniepoint","Opay","Palmpay","Parallex Bank","Polaris Bank",
  "Premium Trust Bank","Providus Bank","Stanbic IBTC Bank",
  "Standard Chartered Bank Nigeria","Sterling Bank","SunTrust Bank",
  "Union Bank of Nigeria","United Bank for Africa (UBA)","Unity Bank",
  "Wema Bank","Zenith Bank","Titan Trust Bank","TAJ Bank","Optimus Bank",
  "Nova Bank","Signature Bank","Coronation Merchant Bank"
];

const nowDate = () => new Date().toISOString().slice(0,10);
const reference = () => "GZB-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).slice(2,7).toUpperCase();

function auth(req,res,next){
  if(!req.session.userId) return res.status(401).json({error:"Not authenticated"});
  next();
}

function userById(id){
  return db.prepare("SELECT * FROM users WHERE id=?").get(id);
}

function safeUser(u){
  return {
    id:u.id, fullName:u.full_name, phone:u.phone, email:u.email,
    balance:u.balance, welcomeClaimed:!!u.welcome_claimed,
    lastDailyReward:u.last_daily_reward, createdAt:u.created_at
  };
}

function addTransaction(userId, type, amount, description, narration="", recipient={}){
  const ref = reference();
  db.prepare(`
    INSERT INTO transactions
    (user_id,type,amount,description,narration,recipient_name,recipient_account,recipient_bank,reference)
    VALUES (?,?,?,?,?,?,?,?,?)
  `).run(
    userId,type,amount,description,narration,
    recipient.name || null, recipient.account || null, recipient.bank || null, ref
  );
  return ref;
}

function applyDailyReward(userId){
  const u = userById(userId);
  const today = nowDate();
  if(!u || u.last_daily_reward === today) return false;

  db.prepare("UPDATE users SET balance=balance+1000,last_daily_reward=? WHERE id=?")
    .run(today,userId);
  addTransaction(userId,"credit",1000,"Daily demo reward","Daily sandbox credit");
  return true;
}

app.get("/api/banks",(req,res)=>res.json({banks}));

app.post("/api/signup", async (req,res)=>{
  const {fullName,phone,email,loginPin,transferPin} = req.body;
  if(!fullName || !phone || !email || !/^\d{6}$/.test(loginPin||"") || !/^\d{4}$/.test(transferPin||"")){
    return res.status(400).json({error:"Complete all fields with a 6-digit login PIN and 4-digit transfer PIN."});
  }
  const exists = db.prepare("SELECT id FROM users WHERE phone=? OR email=?").get(phone,email);
  if(exists) return res.status(409).json({error:"Phone number or email is already registered."});

  const loginHash = await bcrypt.hash(loginPin,12);
  const transferHash = await bcrypt.hash(transferPin,12);

  const result = db.prepare(`
    INSERT INTO users(full_name,phone,email,login_pin_hash,transfer_pin_hash)
    VALUES(?,?,?,?,?)
  `).run(fullName.trim(),phone.trim(),email.trim().toLowerCase(),loginHash,transferHash);

  res.json({ok:true,userId:result.lastInsertRowid});
});

app.post("/api/login", async (req,res)=>{
  const {identity,loginPin} = req.body;
  const u = db.prepare("SELECT * FROM users WHERE phone=? OR email=?")
    .get(identity, (identity||"").toLowerCase());

  if(!u || !(await bcrypt.compare(loginPin||"",u.login_pin_hash))){
    return res.status(401).json({error:"Invalid login details."});
  }

  req.session.userId = u.id;
  applyDailyReward(u.id);

  res.json({ok:true,user:safeUser(userById(u.id))});
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/me",auth,(req,res)=>{
  applyDailyReward(req.session.userId);
  res.json({user:safeUser(userById(req.session.userId))});
});

app.post("/api/claim-welcome",auth,(req,res)=>{
  const u = userById(req.session.userId);
  if(u.welcome_claimed) return res.status(400).json({error:"Welcome bonus already claimed."});

  db.prepare("UPDATE users SET balance=balance+75000,welcome_claimed=1 WHERE id=?")
    .run(u.id);
  const ref = addTransaction(u.id,"credit",75000,"Welcome demo credit","Sandbox welcome credit");
  res.json({ok:true,reference:ref,user:safeUser(userById(u.id))});
});

/*
  SANDBOX account lookup.
  It deliberately does not query a real bank or payment network.
*/
app.post("/api/account-lookup",auth,(req,res)=>{
  const {accountNumber,bank} = req.body;
  if(!/^\d{10}$/.test(accountNumber||"") || !banks.includes(bank)){
    return res.status(400).json({error:"Enter a 10-digit account number and select a bank."});
  }
  res.json({
    verified:true,
    accountName:"Demo Recipient",
    accountNumber,
    bank
  });
});

app.post("/api/transfer",auth,async (req,res)=>{
  const {accountNumber,bank,amount,narration,transferPin} = req.body;
  const value = Number(amount);
  const u = userById(req.session.userId);

  if(!/^\d{10}$/.test(accountNumber||"") || !banks.includes(bank))
    return res.status(400).json({error:"Invalid demo recipient details."});

  if(!Number.isInteger(value) || value <= 0)
    return res.status(400).json({error:"Enter a valid whole-naira amount."});

  if(value > u.balance)
    return res.status(400).json({error:"Insufficient demo balance."});

  if(!(await bcrypt.compare(transferPin||"",u.transfer_pin_hash)))
    return res.status(401).json({error:"Incorrect transfer PIN."});

  const tx = db.transaction(()=>{
    db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(value,u.id);
    return addTransaction(
      u.id,"debit",-value,
      "Transfer to Demo Recipient",
      narration || "Transfer",
      {name:"Demo Recipient",account:accountNumber,bank}
    );
  });
  const ref = tx();

  res.json({
    ok:true,
    reference:ref,
    amount:value,
    recipient:{name:"Demo Recipient",account:accountNumber,bank},
    narration:narration || "Transfer",
    user:safeUser(userById(u.id))
  });
});

app.get("/api/transactions",auth,(req,res)=>{
  const rows = db.prepare(`
    SELECT id,type,amount,description,narration,recipient_name recipientName,
           recipient_account recipientAccount,recipient_bank recipientBank,
           reference,created_at createdAt
    FROM transactions WHERE user_id=? ORDER BY id DESC
  `).all(req.session.userId);
  res.json({transactions:rows});
});

app.listen(PORT,()=>console.log(`Gen Z Bank sandbox running on http://localhost:${PORT}`));
